require 'rubygems'
require 'faraday'
require 'Selenium-webdriver'
require 'cucumber'

driver = Selenium::WebDriver.for :chrome
driver.navigate.to "http://www.zillow.com"

sleep 5000